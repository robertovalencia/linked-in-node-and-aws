# NodeJs/AWS: technical study pack

Start with the [study path](docs/nodejs-aws-study-path/README.md) or the [service-specific technical handbooks](docs/nodejs-beginner/README.md).

Each concept has a short definition, library/runtime mechanics, an actual code excerpt, a fixed GitHub line link, a trap and a recall question. Study one concept, open its code and explain it before moving on.

The twenty lessons and four technical handbooks cover Node.js, NestJS, crypto/JWT, Zod, pg, fetch, KafkaJS, React, testing and AWS. Practical walkthroughs and a twelve-week/six-week roadmap are included. Code links require access to the private repository; the written study material can be read offline.

Source excerpts are not standalone programs unless explicitly labeled runnable. Cloud and proposed feature labs are learning instructions, not deployment claims. The progress file is a blank template; this archive excludes existing personal notes, comments, saved AI expansions and credentials.
