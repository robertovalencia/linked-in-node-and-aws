# NodeJs/AWS study path

Installed in the Interview Process app. Open http://127.0.0.1:8765/guide/nodejs-aws--00-roadmap-and-mastery-gates or select NodeJs/AWS in the top bar.

Includes twenty lessons, twelve-week and six-week routes, urgent interview preparation, labs, model answers, mastery checks, and technology/role coverage matrices.

The six service guides are installed inside /Users/robertovalencia/Documents/Business/linked-in-node-and-aws/docs/nodejs-beginner/. Begin with README.md. They trace startup, dependency injection, all four services, React, events, local debugging, and AWS.

Existing Java/DevOps notes and credentials were preserved. Tests: 76 Python tests completed with one skip; 15 JavaScript tests passed; browser checks covered all 21 Node profile documents, links, search, switching, refresh, mobile and dark theme. Docker/AWS learner labs are documented and were not executed for this documentation task.
